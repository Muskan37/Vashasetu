Vashasetu — UI Design (updated, Lab 5)
Files: mockup.html (high fidelity, 10 screens), wireframes.html (low fidelity, same 10 screens), styles.css (keep next to mockup.html).
Open the .html files in a browser, or import them into Figma with the html.to.design plugin.
Screens: Splash, Translate (Detect + Swap), Language Picker, Translate Result, Word Card, The Bridge, Dictionary (Words), History, Contribute, Profile.
